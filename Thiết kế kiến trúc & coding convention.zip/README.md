# Gym Management - System Architect

Website tĩnh trình bày kiến trúc dự án Gym Management.

## Chạy local

Mở `index.html` trực tiếp bằng trình duyệt.

## Chạy bằng GitHub Pages

1. Tạo repository trên GitHub.
2. Upload `index.html`.
3. Vào Settings → Pages.
4. Chọn Deploy from a branch.
5. Chọn branch `main`, folder `/ (root)`.
6. Save.
7. GitHub Pages sẽ tạo địa chỉ website cho repository.

## Lưu ý

`index.html` là website tĩnh. Các endpoint REST được trình bày trong tài liệu; chúng chưa kết nối tới backend trong bản GitHub Pages này.
